<?php 
echo '<form>
<label>Enter heart
</form>
';
?>